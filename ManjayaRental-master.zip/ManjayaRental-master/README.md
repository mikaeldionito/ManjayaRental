# CarouselView Android Library Example

A simple example for [CarouselView](https://github.com/sayyam/carouselview/) Android library usage. 

![](./art/carouselviewsederhana.gif)
